package com.example.lloydssharedealing.ui.home

import android.widget.VideoView
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class HomeViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "\n" +"SHARE DEALING ACCOUNT " +
                "\n" +
                "A Share Dealing Account is a simple, low-cost way to buy, sell and hold your investments. It’s free to open and we don’t charge any annual fees – you only pay a dealing commission each time you trade.\n" +
                "\n" +
                "With Halifax, we’ve made our Share Dealing Account as flexible as possible. You can choose from a wide variety of investment options, including UK and international shares, funds, exchange traded funds (ETFs), bonds and gilts\n" +
        "\n" +
                "The value of an investment can fall as well as rise, and you may get back less than you invest. If you are not sure about investing, seek independent advice. Tax treatment depends on personal circumstances and may be subject to change."
    }
    val text: LiveData<String> = _text

}