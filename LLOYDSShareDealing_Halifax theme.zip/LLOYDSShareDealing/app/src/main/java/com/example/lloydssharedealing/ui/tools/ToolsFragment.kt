package com.example.lloydssharedealing.ui.tools

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.example.lloydssharedealing.R

class ToolsFragment : Fragment() {

    private lateinit var toolsViewModel: ToolsViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        toolsViewModel =
            ViewModelProviders.of(this).get(ToolsViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_tools, container, false)
        val textView: TextView = root.findViewById(R.id.text_tools)
        toolsViewModel.text.observe(this, Observer {
            textView.text = it
        })
        //init the edittext
        val etMessage: TextView = root.findViewById(R.id.editText)
        val etMessage2: TextView = root.findViewById(R.id.editText2)
        //init the button
        val btnClick: Button = root.findViewById(R.id.button)
        btnClick.setOnClickListener{
            //read value from EditText to a String variable
            val msg: String = etMessage.text.toString()
            val msg2: String =etMessage2.text.toString()

            //check if the EditText have values or not
            if(msg.trim().length>0 && msg2.trim().length>0) {
                Toast.makeText(activity, "Thanks for your Dealing", Toast.LENGTH_SHORT).show()
            }else{
                Toast.makeText(activity, "Please enter valid Information! ", Toast.LENGTH_SHORT).show()
            }
        }
        val btnClick2: Button = root.findViewById(R.id.button2)
        btnClick2.setOnClickListener{
            //read value from EditText to a String variable
            val msg: String = etMessage.text.toString()
            val msg2: String =etMessage2.text.toString()

            //check if the EditText have values or not
            if(msg.trim().length>0 && msg2.trim().length>0) {
                Toast.makeText(activity, "Thanks for your Dealing", Toast.LENGTH_SHORT).show()
            }else{
                Toast.makeText(activity, "Please enter valid Information! ", Toast.LENGTH_SHORT).show()
            }
        }
        return root
    }
}