package com.example.lloydssharedealing.ui.share

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ShareViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is Dealing History Page. Under Construction....!"
    }
    val text: LiveData<String> = _text
}