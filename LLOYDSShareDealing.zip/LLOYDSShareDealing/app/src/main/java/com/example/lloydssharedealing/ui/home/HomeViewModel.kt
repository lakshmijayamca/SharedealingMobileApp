package com.example.lloydssharedealing.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class HomeViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "SHARE DEALING ACCOUNT " +
                "\n" +
                "A Share Dealing Account is a simple, low-cost way to buy, sell and hold your investments. It’s free to open and we don’t charge any annual fees – you only pay a dealing commission each time you trade.\n" +
                "\n" +
                "With Lloyds, we’ve made our Share Dealing Account as flexible as possible. You can choose from a wide variety of investment options, including UK and international shares, funds, exchange traded funds (ETFs), bonds and gilts"
    }
    val text: LiveData<String> = _text
}